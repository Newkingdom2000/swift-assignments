import UIKit


func sayHello(m:String) {
    print(m)
    
}

func doAdd(_ a:Int, _ b:Int) -> Int {
    var sum = a + b
    return sum
}

let result = doAdd(3, 4)
print(result)
